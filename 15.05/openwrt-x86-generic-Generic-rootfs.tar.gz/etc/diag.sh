#!/bin/sh
# Copyright (C) 2006-2009 OpenWrt.org

set_state() { :; }
